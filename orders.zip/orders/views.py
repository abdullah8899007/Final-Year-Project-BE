from rest_framework.permissions import IsAuthenticated
from rest_framework import viewsets
from .models import  *
from .serializers import OrdersSerializer, InvoiceSerializer

# Create your views here.

class OrderViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = OrdersSerializer

    def get_queryset(self):
        return Orders.objects.select_related('customer').all()



class InvoiceViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = InvoiceSerializer

    def get_queryset(self):
        return Invoice.objects.select_related('order', 'order__customer').all()

