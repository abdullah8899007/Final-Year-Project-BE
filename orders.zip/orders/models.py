import uuid
from django.db import models
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from django.core.exceptions import ValidationError
from menu.models import Item, Category, Deal
from decimal import Decimal
from random import randint
from django.db.models import F
from customers.models import CustomersModel
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse



# Create your models here.

class Orders(models.Model):

    READY = 'Ready'
    ENQUEUE = 'Enqueue'
    COMPLETED = 'Completed'
    CANCEL = 'Cancel'

    My_Choices_status = [
        (READY, 'Ready'),
        (ENQUEUE, 'Enqueue'),
        (COMPLETED, 'Completed'),
        (CANCEL, 'Cancel'),
    ]


    LUNCH = "Lunch"
    DINNER = "Dinner"

    order_type_choices = [
        (LUNCH, 'Lunch'),
        (DINNER, 'Dinner'),
    ]

    customer = models.ForeignKey(CustomersModel, on_delete=models.CASCADE)
    items = models.JSONField(default=dict, null=True)
    deals = models.JSONField(default=dict, null=True)
    status = models.CharField(
        max_length=20, choices=My_Choices_status, default="Enqueue", null=False)
    orderType = models.CharField(max_length=25, choices=order_type_choices, null=False)
    total = models.PositiveIntegerField(null=False)
    created_at = models.DateTimeField(auto_now_add=True, null=False)


    def save(self, *args, **kwargs):
        if not self.items and not self.deals:
            raise ValidationError("Either 'items' or 'deals' must be provided.")

        # for item_name, quantity in self.items.items():
        #     try:
        #         item = Item.objects.get(name=item_name)
        #         if quantity > item.stock:
        #             raise ValidationError(f"Quantity of {item_name} exceeds available stock")
        #         item.stock = F('stock') - quantity
        #         item.sold = F('sold') + quantity
        #         item.save(update_fields=['stock', 'sold'])
        #     except Item.DoesNotExist:
        #         pass

        # for deal_name, quantity in self.deals.items():
        #     try:
        #         deal = Deal.objects.get(name=deal_name)
        #         for item_name, item_quantity in deal.items.items():
        #             try:
        #                 item = Item.objects.get(name=item_name)
        #                 if item_quantity * quantity > item.stock:
        #                     raise ValidationError(f"Quantity of {deal_name} exceeds available stock for item {item_name}")
        #                 item.stock = F('stock') - item_quantity * quantity
        #                 item.sold = F('sold') + item_quantity * quantity
        #                 item.save(update_fields=['stock', 'sold'])
        #             except Item.DoesNotExist:
        #                 pass
        #     except Deal.DoesNotExist:
        #         pass

        super().save(*args, **kwargs)

    def __str__(self):
        return self.customer.name

    class Meta:
        verbose_name_plural = "Orders"



class Invoice(models.Model):
    invoice_id = models.PositiveBigIntegerField(editable=False, unique=True)
    order = models.OneToOneField(
        Orders, on_delete=models.CASCADE, related_name='invoice')
    issued_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.invoice_id:
            self.invoice_id = randint(100000, 999999)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Invoice {self.invoice_id} for order {self.order_id}"