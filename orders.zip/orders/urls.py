from django.urls import path
from .views import *
from rest_framework.routers import DefaultRouter

app_name = 'orders' 


router = DefaultRouter()

router.register('orders', OrderViewSet, basename='orders')
router.register('invoices', InvoiceViewSet, basename='invoices')

urlpatterns = [
    
] + router.urls
